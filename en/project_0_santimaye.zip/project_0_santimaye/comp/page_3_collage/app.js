


 var isCollageOn = false;
 var isCollageOn_Image = "";




$(".Collage-Item").click(function(){
    
    var thisUrl = $(this).children();
    var bg_url = thisUrl.css('background-image');

    
    
});