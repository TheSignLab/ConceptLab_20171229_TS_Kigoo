 var introLocked = true;
 var currentPage = 0;




 setTimeout(function () {

     $(".Intro-Bg-FullSize .Layer .title").css({
         "left": "0px"
     });

     setTimeout(function () {

         $(".Intro-Bg-FullSize .Layer .subtitle").css({
             "left": "0px"
         });
         $(".Intro-Bg-FullSize .Layer p").css({
             "left": "0px"
         });

     }, 500);

 }, 500);




 setTimeout(function () {
     introLocked = false;
 }, 300);


 function updateSection1() {

     $(document).on('DOMMouseScroll mousewheel', function () {

         if (!introLocked) {

             $(".Header").css({
                 "top": "0px"
             });

             $(".Layer").fadeOut(1500, function () {

                 $('main').fullpage.setAllowScrolling(true);
                 $('main').fullpage.setMouseWheelScrolling(true);

             });
         }



     });




 }

 /*

  window.addEventListener('wheel', function (e) {



      if (e.deltaY < 0) {
          window.userScrollDirection = "Down";
      }
      if (e.deltaY > 0) {
          window.userScrollDirection = "Up";
      }




      if (currentPage == 0 && e.deltaY < 0) //Estoy en 0 y voy arriba
      {

          currentPage = 0;
      }
      if (currentPage == 0 && e.deltaY > 0) //Estoy en 0 y voy abajo
      {

          currentPage = 1;
      }




      if (currentPage == 1 && e.deltaY < 0) //Estoy en 1 y voy arriba
      {

          currentPage = 0;
      }
      if (currentPage == 1 && e.deltaY > 0) //Estoy en 1 y voy abajo
      {

         // $('main').fullpage.moveSectionDown();

      }



      console.log(currentPage)





  });
 */
