var vFullPageCurrentSectionIndex = 0;
$(document).ready(function () {

    $('main').fullpage({
        sectionSelector: 'section',






        onLeave: function (index, nextIndex, direction) {
            
    

            if (nextIndex == 2 || index == 2) {

                $(".Collage-Space").css({
                    "height": "0px"
                });

            }

        },








        afterLoad: function (anchorLink, index) {
            currentPage = index;
            if (index == 1) {
                updateSection1();
            }

            if (index == 2) {

                $(".Collage-Space").css({
                    "height": "150px"
                });

            }








        },
    });

    $('main').fullpage.setAllowScrolling(false);
    $('main').fullpage.setMouseWheelScrolling(false);




});
